#!/bin/bash
# =============================================================================
# Script 2: FOSS Package Inspector
# Author: [Your Name] | Reg No: [Your Reg No]
# Course: Open Source Software | OSS NGMC Capstone
# Description: Checks if a given FOSS package is installed, shows its version
#              and license info, and prints a philosophy note using case.
# Usage: Run without arguments to check the default package (linux-image-*),
#        or pass a package name: ./script2_foss_inspector.sh <package>
# =============================================================================

# --- Package to inspect ---
# Use command-line argument if provided, otherwise default to the Linux kernel
# $1 is the first argument passed to the script; ${1:-default} uses default if $1 is empty
PACKAGE=${1:-"linux-image-$(uname -r)"}

echo "=============================================="
echo "  FOSS Package Inspector"
echo "  Checking package: $PACKAGE"
echo "=============================================="
echo ""

# --- Detect package manager and check installation ---
# Different distros use different package managers (rpm vs dpkg)
# We check which one exists on this system using 'command -v'

if command -v rpm &>/dev/null; then
    # --- RPM-based system (Fedora, RHEL, CentOS) ---
    echo "[INFO] Detected RPM-based system."
    echo ""

    # rpm -q checks if a package is installed; redirect output to suppress it
    if rpm -q "$PACKAGE" &>/dev/null; then
        echo "[OK] $PACKAGE is INSTALLED."
        echo ""
        echo "--- Package Details ---"
        # rpm -qi gives full info; grep -E filters to show only key fields
        rpm -qi "$PACKAGE" | grep -E 'Name|Version|License|Summary|URL'
    else
        echo "[NOT FOUND] $PACKAGE is NOT installed on this system."
        echo "To install it, try: sudo dnf install $PACKAGE"
    fi

elif command -v dpkg &>/dev/null; then
    # --- Debian/Ubuntu-based system ---
    echo "[INFO] Detected Debian/dpkg-based system."
    echo ""

    # dpkg -l lists packages; we pipe to grep to check for an exact match
    if dpkg -l "$PACKAGE" 2>/dev/null | grep -q '^ii'; then
        echo "[OK] $PACKAGE is INSTALLED."
        echo ""
        echo "--- Package Details ---"
        # dpkg -s gives detailed status; grep filters to relevant fields
        dpkg -s "$PACKAGE" 2>/dev/null | grep -E 'Package|Version|Maintainer|Description'
    else
        echo "[NOT FOUND] $PACKAGE is NOT installed on this system."
        echo "To install it, try: sudo apt install $PACKAGE"
    fi

else
    # Neither rpm nor dpkg found — unusual but handled gracefully
    echo "[WARN] Could not detect a known package manager (rpm or dpkg)."
    echo "Falling back to kernel version detection using uname."
    echo ""
    echo "Running Kernel Version : $(uname -r)"
    echo "Kernel Architecture    : $(uname -m)"
fi

echo ""
echo "--- Open Source Philosophy Note ---"

# --- case statement: prints a philosophy note based on the package name ---
# The pattern matching uses wildcards (*) to handle version suffixes
case "$PACKAGE" in
    linux-image*|linux-kernel*|kernel*)
        echo "Linux Kernel: The GPL-licensed core that runs on everything from"
        echo "smartphones to supercomputers. Linus built it so no one would ever"
        echo "need to beg a company for the right to fix their own computer."
        ;;
    httpd|apache*)
        echo "Apache HTTP Server: The web server that made the open internet."
        echo "It proved that community-built software could outperform corporate products."
        ;;
    mysql*|mariadb*)
        echo "MySQL: A dual-licensed database at the heart of millions of web apps."
        echo "Its story shows how open source licensing shapes business models."
        ;;
    firefox*)
        echo "Firefox: A nonprofit browser fighting for an open, user-controlled web."
        echo "Its existence reminds us that market dominance is not the only goal."
        ;;
    vlc*)
        echo "VLC: Built by students who just wanted to watch video over a network."
        echo "It is proof that scratching your own itch can change the world."
        ;;
    git*)
        echo "Git: Linus built it in two weeks when proprietary version control failed him."
        echo "It now underpins virtually all software development on the planet."
        ;;
    python*)
        echo "Python: Shaped entirely by its community through PEPs (proposals)."
        echo "Its permissive PSF license made it the world's most-used language."
        ;;
    *)
        echo "$PACKAGE: Every open-source package carries someone's decision"
        echo "to share their work freely. That decision compounds over time."
        ;;
esac

echo ""
echo "=============================================="
