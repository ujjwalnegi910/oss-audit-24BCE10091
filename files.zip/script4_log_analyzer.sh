#!/bin/bash
# =============================================================================
# Script 4: Log File Analyzer
# Author: [Your Name] | Reg No: [Your Reg No]
# Course: Open Source Software | OSS NGMC Capstone
# Description: Reads a log file line by line, counts occurrences of a keyword,
#              prints the last 5 matching lines, and retries if the file is empty.
# Usage: ./script4_log_analyzer.sh <logfile> [keyword]
# Example: ./script4_log_analyzer.sh /var/log/syslog error
# =============================================================================

# --- Command-line arguments ---
# $1 = log file path (required)
# $2 = keyword to search for (optional, defaults to "error")
LOGFILE=$1
KEYWORD=${2:-"error"}

# --- Validate that the user actually provided a file path ---
if [ -z "$LOGFILE" ]; then
    echo "Usage: $0 <logfile> [keyword]"
    echo "Example: $0 /var/log/syslog error"
    exit 1
fi

echo "================================================================"
echo "  Log File Analyzer"
echo "  File    : $LOGFILE"
echo "  Keyword : '$KEYWORD' (case-insensitive)"
echo "================================================================"
echo ""

# --- Retry loop: attempt up to 3 times if the file is empty ---
# This simulates a do-while pattern: we always try at least once,
# then check the condition at the end of each iteration
MAX_RETRIES=3
ATTEMPT=0

while [ $ATTEMPT -lt $MAX_RETRIES ]; do

    ATTEMPT=$((ATTEMPT + 1))

    # Check if the file exists at all
    if [ ! -f "$LOGFILE" ]; then
        echo "[ERROR] File not found: $LOGFILE"
        echo "        Attempt $ATTEMPT of $MAX_RETRIES. Retrying in 2 seconds..."
        sleep 2
        continue  # Skip to the next loop iteration
    fi

    # Check if the file is empty using -s (true if file exists and has size > 0)
    if [ ! -s "$LOGFILE" ]; then
        echo "[WARN] File exists but is empty: $LOGFILE"
        echo "       Attempt $ATTEMPT of $MAX_RETRIES. Retrying in 2 seconds..."
        sleep 2
        continue
    fi

    # File exists and is not empty — break out of the retry loop
    echo "[OK] File found and readable. Starting analysis..."
    break

done

# After the retry loop, do a final check before proceeding
if [ ! -f "$LOGFILE" ] || [ ! -s "$LOGFILE" ]; then
    echo ""
    echo "[FATAL] Could not read a valid log file after $MAX_RETRIES attempts."
    echo "        Please check the file path and try again."
    exit 1
fi

echo ""

# --- Count keyword occurrences using while-read loop ---
# IFS= prevents leading/trailing whitespace from being stripped
# read -r prevents backslash interpretation
COUNT=0
LINE_NUMBERS=()   # Array to store line numbers of matches

CURRENT_LINE=0

while IFS= read -r LINE; do

    CURRENT_LINE=$((CURRENT_LINE + 1))

    # grep -i makes the search case-insensitive
    # -q suppresses output; we only care about the exit code (0 = match found)
    if echo "$LINE" | grep -iq "$KEYWORD"; then
        COUNT=$((COUNT + 1))
        # Store the line number of each match in the array
        LINE_NUMBERS+=($CURRENT_LINE)
    fi

done < "$LOGFILE"

# --- Display results summary ---
TOTAL_LINES=$CURRENT_LINE
echo "  Total lines in file : $TOTAL_LINES"
echo "  Keyword matches     : $COUNT"

# Calculate match percentage using awk (bash can't do floating point natively)
if [ $TOTAL_LINES -gt 0 ]; then
    PERCENTAGE=$(awk "BEGIN {printf \"%.1f\", ($COUNT / $TOTAL_LINES) * 100}")
    echo "  Match percentage    : $PERCENTAGE%"
fi

echo ""

# --- Show the last 5 matching lines ---
# We use grep -n to get line numbers, then tail to get the last 5 matches
if [ $COUNT -gt 0 ]; then
    echo "--- Last 5 lines matching '$KEYWORD' ---"
    # grep -in: -i for case-insensitive, -n to show line numbers
    # tail -5 takes only the last 5 results
    grep -in "$KEYWORD" "$LOGFILE" | tail -5
else
    echo "  [INFO] No lines matched keyword '$KEYWORD' in $LOGFILE"
    echo "         Try a different keyword or check the file contents."
fi

echo ""
echo "================================================================"
echo "  Tip: Linux kernel messages are logged to /var/log/kern.log"
echo "  or accessible via the 'dmesg' command. Try:"
echo "  dmesg > /tmp/kernel_log.txt"
echo "  ./script4_log_analyzer.sh /tmp/kernel_log.txt error"
echo "================================================================"
