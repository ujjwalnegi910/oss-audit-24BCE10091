#!/bin/bash
# =============================================================================
# Script 1: System Identity Report
# Author: [Your Name] | Reg No: [Your Reg No]
# Course: Open Source Software | OSS NGMC Capstone
# Description: Displays a formatted welcome screen with system information
#              including kernel version, user details, uptime, and OS license.
# =============================================================================

# --- Student and software identification variables ---
STUDENT_NAME="[Your Name]"
REG_NO="[Your Registration Number]"
SOFTWARE_CHOICE="Linux Kernel"

# --- Gather system information using command substitution ---
# uname -r returns the running kernel version (e.g., 5.15.0-91-generic)
KERNEL=$(uname -r)

# uname -s returns the kernel name (Linux)
KERNEL_NAME=$(uname -s)

# whoami returns the current logged-in username
USER_NAME=$(whoami)

# $HOME is a built-in shell variable pointing to the user's home directory
HOME_DIR=$HOME

# uptime -p returns human-readable uptime (e.g., "up 2 hours, 15 minutes")
UPTIME=$(uptime -p)

# date with format string returns current date and time
CURRENT_DATETIME=$(date '+%A, %d %B %Y at %H:%M:%S')

# Read the Linux distribution name from the os-release file
# /etc/os-release is a standard file present on all modern Linux distros
if [ -f /etc/os-release ]; then
    # Source the file to load its variables, then extract PRETTY_NAME
    DISTRO=$(grep '^PRETTY_NAME' /etc/os-release | cut -d '=' -f2 | tr -d '"')
else
    # Fallback if the file doesn't exist (older systems)
    DISTRO="Unknown Linux Distribution"
fi

# The OS license — Linux kernel is released under GPL version 2
OS_LICENSE="GNU General Public License v2 (GPL-2.0)"

# --- Display the formatted system identity report ---
echo "================================================================"
echo "         OPEN SOURCE AUDIT — SYSTEM IDENTITY REPORT            "
echo "================================================================"
echo ""
echo "  Student   : $STUDENT_NAME ($REG_NO)"
echo "  Project   : $SOFTWARE_CHOICE"
echo ""
echo "----------------------------------------------------------------"
echo "  SYSTEM INFORMATION"
echo "----------------------------------------------------------------"
echo "  Distribution  : $DISTRO"
echo "  Kernel        : $KERNEL_NAME $KERNEL"
echo "  Logged in as  : $USER_NAME"
echo "  Home Dir      : $HOME_DIR"
echo "  System Uptime : $UPTIME"
echo "  Date & Time   : $CURRENT_DATETIME"
echo ""
echo "----------------------------------------------------------------"
echo "  LICENSE"
echo "----------------------------------------------------------------"
echo "  This operating system is covered by the:"
echo "  $OS_LICENSE"
echo ""
echo "  The GPL-2.0 guarantees four essential freedoms:"
echo "  [0] Freedom to run the program for any purpose"
echo "  [1] Freedom to study and change the source code"
echo "  [2] Freedom to redistribute copies"
echo "  [3] Freedom to distribute modified versions"
echo ""
echo "================================================================"
echo "  'The kernel is the piece of software that connects"
echo "   your hardware to everything else.' — Linus Torvalds"
echo "================================================================"
