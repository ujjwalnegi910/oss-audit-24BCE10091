#!/bin/bash
# =============================================================================
# Script 3: Disk and Permission Auditor
# Author: [Your Name] | Reg No: [Your Reg No]
# Course: Open Source Software | OSS NGMC Capstone
# Description: Loops through important Linux system directories and reports
#              disk usage, owner, group, and permission string for each.
#              Also checks for the Linux kernel's key configuration path.
# =============================================================================

# --- List of standard Linux directories to audit ---
# These are the most important directories in a Linux filesystem hierarchy
DIRS=("/etc" "/var/log" "/home" "/usr/bin" "/tmp" "/boot" "/lib/modules")

echo "================================================================"
echo "  Disk and Permission Auditor"
echo "  Run by: $(whoami) on $(date '+%d %B %Y %H:%M')"
echo "================================================================"
printf "%-20s %-12s %-30s\n" "Directory" "Size" "Permissions (type user group)"
echo "----------------------------------------------------------------"

# --- for loop: iterate over each directory in the DIRS array ---
for DIR in "${DIRS[@]}"; do

    # Check if the directory actually exists before trying to inspect it
    # -d tests for directory existence
    if [ -d "$DIR" ]; then

        # ls -ld lists the directory itself (not its contents)
        # awk '{print $1, $3, $4}' extracts: permissions, owner, group
        PERMS=$(ls -ld "$DIR" | awk '{print $1, $3, $4}')

        # du -sh gives a human-readable size (-s = summary, -h = human readable)
        # 2>/dev/null suppresses permission-denied errors for protected dirs
        # cut -f1 takes only the size column (tab-delimited output)
        SIZE=$(du -sh "$DIR" 2>/dev/null | cut -f1)

        # If du returned nothing (e.g., access denied), show a placeholder
        SIZE=${SIZE:-"N/A"}

        # printf for clean aligned column output
        printf "%-20s %-12s %-30s\n" "$DIR" "$SIZE" "$PERMS"
    else
        # Directory does not exist on this system — report it clearly
        printf "%-20s %-12s %-30s\n" "$DIR" "---" "[does not exist]"
    fi
done

echo ""
echo "================================================================"
echo "  Linux Kernel — Configuration and Module Directory Check"
echo "================================================================"

# --- Check the Linux kernel's specific config and module paths ---
# /boot holds the kernel image and its config file
# /lib/modules/$(uname -r) holds loadable kernel modules for the running kernel

KERNEL_VERSION=$(uname -r)
KERNEL_CONFIG="/boot/config-$KERNEL_VERSION"
MODULES_DIR="/lib/modules/$KERNEL_VERSION"

echo ""
echo "  Running kernel version: $KERNEL_VERSION"
echo ""

# Check the kernel config file
if [ -f "$KERNEL_CONFIG" ]; then
    # stat -c prints specific fields: %A=permissions, %U=owner, %G=group
    CONFIG_PERMS=$(stat -c "%A %U %G" "$KERNEL_CONFIG")
    CONFIG_SIZE=$(du -sh "$KERNEL_CONFIG" 2>/dev/null | cut -f1)
    echo "  [OK] Kernel config found: $KERNEL_CONFIG"
    echo "       Size: $CONFIG_SIZE | Permissions: $CONFIG_PERMS"
else
    echo "  [INFO] Kernel config not found at $KERNEL_CONFIG"
    echo "         (This is normal on minimised or container systems)"
fi

echo ""

# Check the kernel modules directory
if [ -d "$MODULES_DIR" ]; then
    MOD_PERMS=$(stat -c "%A %U %G" "$MODULES_DIR")
    MOD_SIZE=$(du -sh "$MODULES_DIR" 2>/dev/null | cut -f1)
    echo "  [OK] Kernel modules directory: $MODULES_DIR"
    echo "       Size: $MOD_SIZE | Permissions: $MOD_PERMS"

    # Count the number of loaded modules using lsmod
    # lsmod reads /proc/modules; wc -l counts lines; subtract 1 for header
    LOADED_MODULES=$(lsmod | wc -l)
    echo "       Loaded modules: $((LOADED_MODULES - 1))"
else
    echo "  [INFO] Modules directory not found at $MODULES_DIR"
fi

echo ""
echo "================================================================"
echo "  Note: Directories owned by root with restricted permissions"
echo "  are a security feature — they prevent unprivileged users from"
echo "  modifying critical system files. This is Unix security 101."
echo "================================================================"
